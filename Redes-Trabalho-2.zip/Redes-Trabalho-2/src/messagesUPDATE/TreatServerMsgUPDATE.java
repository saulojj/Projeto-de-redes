package messagesUPDATE;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TreatServerMsgUPDATE {
	public void receivedSYN(int[] header) {
		System.out.println("\n<--ReceivedSYN! (Pedido de Sincronizacao)");

		showHeader(header);
	}
	
	public void sendSYN_ACK(DatagramSocket serverSocket, int clientPort, int[] header) throws IOException {
		System.out.println("\n-->SendSYN_ACK! (Confirmacao de Sincronizacao)");

		showHeader(header);

		byte[] arrayMSG = buildMSG(header);
		InetAddress _IP = InetAddress.getByName("localhost"); // throws UnknownHostException
		DatagramPacket serPacket = new DatagramPacket(arrayMSG, arrayMSG.length, _IP, clientPort);
		serverSocket.send(serPacket);
	}
	
	public byte[] buildMSG(int[] header) {
		String msg = "";
		for(int i = 0; i < header.length; i++) {
			msg += header[i] + " ";
		}
		return  msg.trim().getBytes();
	}
	
	public void showHeader(int[] header) {
		System.out.println("SeqNumber = " + header[0]);
		System.out.println("AckNumber = " + header[1]);
		System.out.println("ConnectionID = " + header[2]);
		System.out.println("ACK = " + header[3] + " SYN = " + header[4] + " FYN = " + header[5]);
	}
}
