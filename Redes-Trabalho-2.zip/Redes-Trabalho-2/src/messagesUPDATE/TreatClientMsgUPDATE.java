package messagesUPDATE;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TreatClientMsgUPDATE {
	public void sendSYN(DatagramSocket clientSocket, int destPort, int[] header) throws IOException {
		System.out.println("\n-->SendSYN! (Pedido de Sincronizacao)");

		showHeader(header);

		byte[] arrayMSG = buildMSG(header).getBytes();
		InetAddress _IP = InetAddress.getByName("localhost"); // throws UnknownHostException
		DatagramPacket packetMSG = new DatagramPacket(arrayMSG, arrayMSG.length, _IP, destPort);
		clientSocket.send(packetMSG);
	}
	
	public void receivedSYN_ACK(int[] header) {
		System.out.println("\n<--ReceivedSYN_ACK! (Confirmacao de Sincronizacao)");

		showHeader(header);
	}
	
	public String buildMSG(int[] header) {
		String msg = "";
		for(int i = 0; i < header.length; i++) {
				msg += header[i] + " ";
		}
		return msg;
	}
	
	public void showHeader(int[] header) {
		System.out.println("SeqNumber = " + header[0]);
		System.out.println("AckNumber = " + header[1]);
		System.out.println("ConnectionID = " + header[2]);
		System.out.println("ACK = " + header[3] + " SYN = "+ header[4] + " FYN = " + header[5]);
	}
}
