package applicationUPDATE;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

import messagesUPDATE.TreatClientMsgUPDATE;

public class ClientUPDATE {
	private int baseSeqNum; 
	private int nextSeqNum; 
	private int ackNum;
	private int connectionID;
	private int ack;
	private int syn;
	private int fyn;
	
	private final int serverPort = 12000;
	private TreatClientMsgUPDATE clientMSG;
	private DatagramSocket clientSocket;
	
	public static void main(String[] args) throws IOException {
		ClientUPDATE client = new ClientUPDATE();
		client.requestConnection();
	}
	
	public ClientUPDATE() throws SocketException {
		this.baseSeqNum = 12345;
		this.nextSeqNum = 12345; 
		this.ackNum = 0;
		this.connectionID = 0;
		this.ack = 0;
		this.syn = 1;
		this.fyn = 0;

		this.clientSocket = new DatagramSocket(); // THROWS SOCKETEXCEPTION
		this.clientMSG = new TreatClientMsgUPDATE();
	}
	
	public void requestConnection() throws IOException {
		System.out.println("-- CLIENTE " + getClientSocket().getLocalPort() + "--");
		int[] header = buildHeader();
		getClientMSG().sendSYN(getClientSocket(), getServerPort(), header);
		
		setNextSeqNum(getBaseSeqNum() + 1);
		
		byte[] bytes = new byte[550];
		DatagramPacket packetUDP = new DatagramPacket(bytes, bytes.length);
		getClientSocket().receive(packetUDP);
		
		String[] msgPacket = new String(packetUDP.getData()).trim().split(" ");
//		String[] header = msgPacket[0].split(" ");
//		String content = msgPacket[1].trim();
		
		int[] freshHeader = convertHeaderInteger(msgPacket);
		if(freshHeader[0] == 4321 && freshHeader[1] == getNextSeqNum() && freshHeader[3] == 1 && freshHeader[4] == 1) {
			getClientMSG().receivedSYN_ACK(freshHeader);
			setBaseSeqNum(freshHeader[1]);
			setAckNum(freshHeader[0] + 1);
			setConnectionID(freshHeader[2]);
			setAck(1);
			setSyn(0);
			setFyn(0);
			
			manageConnection();
		}
	}
	
	public void manageConnection() {
		System.out.println("\n-- Conexao Estabelecida --");
		while(!Thread.currentThread().isInterrupted()) {
			
		}
	}
	
	private int[] convertHeaderInteger(String[] oldHeader) {
		int[] freshHeader = new int[6];
		for(int i = 0; i < oldHeader.length; i++) {
			freshHeader[i] = Integer.parseInt(oldHeader[i]);
		}
		return freshHeader;
	}
	
	private int[] buildHeader() {
		int[] header = new int[6];
		header[0] = getBaseSeqNum();
		header[1] = getAckNum();
		header[2] = getConnectionID();
		header[3] = getAck();
		header[4] = getSyn();
		header[5] = getFyn();
		return header;
	}

	public int getBaseSeqNum() {
		return baseSeqNum;
	}

	public void setBaseSeqNum(int baseSeqNum) {
		this.baseSeqNum = baseSeqNum;
	}

	public int getNextSeqNum() {
		return nextSeqNum;
	}

	public void setNextSeqNum(int nextSeqNum) {
		this.nextSeqNum = nextSeqNum;
	}

	public int getAckNum() {
		return ackNum;
	}

	public void setAckNum(int ackNum) {
		this.ackNum = ackNum;
	}

	public int getConnectionID() {
		return connectionID;
	}

	public void setConnectionID(int connectionID) {
		this.connectionID = connectionID;
	}

	public int getAck() {
		return ack;
	}

	public void setAck(int ack) {
		this.ack = ack;
	}

	public int getSyn() {
		return syn;
	}

	public void setSyn(int syn) {
		this.syn = syn;
	}

	public int getFyn() {
		return fyn;
	}

	public void setFyn(int fyn) {
		this.fyn = fyn;
	}

	public TreatClientMsgUPDATE getClientMSG() {
		return clientMSG;
	}

	public void setClientMSG(TreatClientMsgUPDATE clientMSG) {
		this.clientMSG = clientMSG;
	}

	public DatagramSocket getClientSocket() {
		return clientSocket;
	}

	public void setClientSocket(DatagramSocket clientSocket) {
		this.clientSocket = clientSocket;
	}

	public int getServerPort() {
		return serverPort;
	}
	
}
