package applicationUPDATE;

import java.net.DatagramSocket;

import messagesUPDATE.TreatClientMsgUPDATE;

public class IsConnected extends Thread{
	private int baseSeqNum; 
	private int nextSeqNum; 
	private int ackNum;
	private int connectionID;
	private int ack;
	private int syn;
	private int fyn;
	
	private int port;
	private final int serverPort = 12000;
	private DatagramSocket serverSocket;
	private TreatClientMsgUPDATE clientMSG;
	
	public IsConnected(DatagramSocket serverSocket, int id, int port) {
		this.baseSeqNum = 4323;
		this.nextSeqNum = 4323;
		this.ackNum = 0;
		this.connectionID = 1;
		this.ack = 1;
		this.syn = 0;
		this.fyn = 0;
		
		this.port = port;
		this.serverSocket = serverSocket;
		this.clientMSG = new TreatClientMsgUPDATE();
	}
	
	@Override
	public void run() {
		System.out.println("\nNova Conexao estabelecida " + getPort());
		while (!isInterrupted()) {
		}
	}

	public int getBaseSeqNum() {
		return baseSeqNum;
	}

	public void setBaseSeqNum(int baseSeqNum) {
		this.baseSeqNum = baseSeqNum;
	}

	public int getNextSeqNum() {
		return nextSeqNum;
	}

	public void setNextSeqNum(int nextSeqNum) {
		this.nextSeqNum = nextSeqNum;
	}

	public int getAckNum() {
		return ackNum;
	}

	public void setAckNum(int ackNum) {
		this.ackNum = ackNum;
	}

	public int getConnectionID() {
		return connectionID;
	}

	public void setConnectionID(int connectionID) {
		this.connectionID = connectionID;
	}

	public int getAck() {
		return ack;
	}

	public void setAck(int ack) {
		this.ack = ack;
	}

	public int getSyn() {
		return syn;
	}

	public void setSyn(int syn) {
		this.syn = syn;
	}

	public int getFyn() {
		return fyn;
	}

	public void setFyn(int fyn) {
		this.fyn = fyn;
	}

	public TreatClientMsgUPDATE getClientMSG() {
		return clientMSG;
	}

	public void setClientMSG(TreatClientMsgUPDATE clientMSG) {
		this.clientMSG = clientMSG;
	}

	public DatagramSocket getServerSocket() {
		return serverSocket;
	}

	public void setServerSocket(DatagramSocket serverSocket) {
		this.serverSocket = serverSocket;
	}

	public int getServerPort() {
		return serverPort;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
}
