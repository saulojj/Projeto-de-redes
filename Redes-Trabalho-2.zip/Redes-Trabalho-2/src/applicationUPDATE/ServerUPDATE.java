package applicationUPDATE;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;

import messagesUPDATE.TreatServerMsgUPDATE;

public class ServerUPDATE {
	private int baseSeqNum; 
	private int nextSeqNum; 
	private int ackNum;
	private int clientID;
	private int ack;
	private int syn;
	private int fyn;
	
	private ArrayList<IsConnected> clientsConnecteds;
	private final int serverPort = 12000;
	private DatagramSocket serverSocket;
	private TreatServerMsgUPDATE serverMSG;
	
	public static void main(String[] args) throws IOException {
		ServerUPDATE server = new ServerUPDATE();
		server.acceptConnection();
	}
	
	public ServerUPDATE() throws SocketException {
		this.baseSeqNum = 4321;
		this.ackNum = 0;
		this.clientID = 0;
		this.ack = 1;
		this.syn = 1;
		this.fyn = 0;
		
		this.serverMSG = new TreatServerMsgUPDATE();
		this.serverSocket = new DatagramSocket(12000); 
		this.clientsConnecteds = new ArrayList<IsConnected>();
	}
	
	public void acceptConnection() throws IOException {
		System.out.println("-- SERVIDOR INICIADO NA PORTA " + getServerPort() + " --");
		while(true) {
			byte[] bytes = new byte[550];
			DatagramPacket packetUDP = new DatagramPacket(bytes, bytes.length);
			getServerSocket().receive(packetUDP);
			
			String[] msgPacket = new String(packetUDP.getData()).trim().split(" ");
//			String[] header = msgPacket[0].split(" ");
//			String content = msgPacket[1].trim();
			
			int[] freshHeader = convertHeaderInteger(msgPacket);
			if(freshHeader[0] == 12345 && freshHeader[2] == 0 && freshHeader[4] == 1) {
				getServerMSG().receivedSYN(freshHeader);
				setAckNum(freshHeader[0] + 1);
				setClientID(getClientID() + 1);
				setAck(1);
				setSyn(1);
				setFyn(0);
				
				int[] header = buildHeader();
				getServerMSG().sendSYN_ACK(getServerSocket(), packetUDP.getPort(), header);
				IsConnected clientConnected = new IsConnected(getServerSocket(), getClientID(), packetUDP.getPort());
				
				getClientsConnecteds().add(clientConnected);
				
				Thread thread = clientConnected;
				thread.start();
			}
		}
	}
	
	private int[] convertHeaderInteger(String[] oldHeader) {
		int[] freshHeader = new int[6];
		for(int i = 0; i < oldHeader.length; i++) {
			freshHeader[i] = Integer.parseInt(oldHeader[i]);
		}
		return freshHeader;
	}
	
	private int[] buildHeader() {
		int[] header = new int[6];
		header[0] = getBaseSeqNum();
		header[1] = getAckNum();
		header[2] = getClientID();
		header[3] = getAck();
		header[4] = getSyn();
		header[5] = getFyn();
		return header;
	}

	public int getBaseSeqNum() {
		return baseSeqNum;
	}

	public void setBaseSeqNum(int baseSeqNum) {
		this.baseSeqNum = baseSeqNum;
	}

	public int getNextSeqNum() {
		return nextSeqNum;
	}

	public void setNextSeqNum(int nextSeqNum) {
		this.nextSeqNum = nextSeqNum;
	}

	public int getAckNum() {
		return ackNum;
	}

	public void setAckNum(int ackNum) {
		this.ackNum = ackNum;
	}

	public int getClientID() {
		return clientID;
	}

	public void setClientID(int clientID) {
		this.clientID = clientID;
	}

	public int getAck() {
		return ack;
	}

	public void setAck(int ack) {
		this.ack = ack;
	}

	public int getSyn() {
		return syn;
	}

	public void setSyn(int syn) {
		this.syn = syn;
	}

	public int getFyn() {
		return fyn;
	}

	public void setFyn(int fyn) {
		this.fyn = fyn;
	}

	public TreatServerMsgUPDATE getServerMSG() {
		return serverMSG;
	}

	public void setServerMSG(TreatServerMsgUPDATE serverMSG) {
		this.serverMSG = serverMSG;
	}

	public DatagramSocket getServerSocket() {
		return serverSocket;
	}

	public void setServerSocket(DatagramSocket serverSocket) {
		this.serverSocket = serverSocket;
	}

	public int getServerPort() {
		return serverPort;
	}

	public ArrayList<IsConnected> getClientsConnecteds() {
		return clientsConnecteds;
	}

	public void setClientsConnecteds(ArrayList<IsConnected> clientsConnecteds) {
		this.clientsConnecteds = clientsConnecteds;
	}
	
}
